﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsFormaZvanjeDetaljiEdit
    {
   // atributi i property
        private string pStringKonekcije;
        private clsZvanjeDB objZvanjeDB;

        private clsZvanje objPreuzetoZvanje;
        private clsZvanje objIzmenjenoZvanje;

        private string pSifraPreuzetogZvanja;
        private string pNazivPreuzetogZvanja;

        private string pSifraIzmenjenogZvanja;
        private string pNazivIzmenjenogZvanja;
        
// PROPERTY

        public string SifraPreuzetogZvanja
        {
            get { return pSifraPreuzetogZvanja; }
            set { pSifraPreuzetogZvanja = value; pNazivPreuzetogZvanja = DajNaziv(pSifraPreuzetogZvanja); }
        }

        public string NazivPreuzetogZvanja
        {
            get { return pNazivPreuzetogZvanja; }
            // OVO NECEMO DA OMOGUCIMO, JER SE RACUNA IZ SIFRE set { pNazivPreuzetogZvanja = value; }
        }

        public string SifraIzmenjenogZvanja
        {
            get { return pSifraIzmenjenogZvanja; }
            set { pSifraIzmenjenogZvanja = value; }
        }


        public string NazivIzmenjenogZvanja
        {
            get { return pNazivIzmenjenogZvanja; }
            set { pNazivIzmenjenogZvanja = value; }
        }


    // konstruktor
        public clsFormaZvanjeDetaljiEdit(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
            objZvanjeDB = new clsZvanjeDB(pStringKonekcije);
        }

        // privatne metode
        private string DajNaziv(string pomSifra)
        {
            string pomNaziv ="";
            DataSet dsPodaci = new DataSet();
            pomNaziv = objZvanjeDB.DajNazivPremaIDZvanja(pomSifra); 

            return pomNaziv;
        }

        // javne metode
        public bool ObrisiZvanje()
        {
            // zvanje koje je trenutno u atributima dato, TJ. preuzeta sifra je bitna
            bool uspehBrisanja = false;
            uspehBrisanja = objZvanjeDB.ObrisiZvanje(pSifraPreuzetogZvanja);  

            return uspehBrisanja;

        }

        public bool IzmeniZvanje()
        {
            bool uspehIzmene = false;
            objPreuzetoZvanje = new clsZvanje();
            objIzmenjenoZvanje = new clsZvanje();

            objPreuzetoZvanje.Sifra = pSifraPreuzetogZvanja;
            objPreuzetoZvanje.Naziv = pNazivPreuzetogZvanja;

            objIzmenjenoZvanje.Sifra = pSifraIzmenjenogZvanja;
            objIzmenjenoZvanje.Naziv = pNazivIzmenjenogZvanja;

            uspehIzmene = objZvanjeDB.IzmeniZvanje(objPreuzetoZvanje, objIzmenjenoZvanje);  

            return uspehIzmene;
        }
    }
}
