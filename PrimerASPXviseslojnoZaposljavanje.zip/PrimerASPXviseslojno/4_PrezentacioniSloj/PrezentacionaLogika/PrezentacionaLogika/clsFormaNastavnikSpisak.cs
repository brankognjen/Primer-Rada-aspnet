﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsFormaNastavnikSpisak
    {
        // atributi
        private string pStringKonekcije;

        // property

        // konstruktor
        public clsFormaNastavnikSpisak(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet dsPodaci = new DataSet();
            clsNastavnikDB objNastavnikDB = new clsNastavnikDB(pStringKonekcije);
            if (filter.Equals(""))
            {
                dsPodaci = objNastavnikDB.DajSveNastavnike(); 
            }
            else
            {
                dsPodaci = objNastavnikDB.DajNastavnikaPoPrezimenu(filter);
            }
            return dsPodaci;
        }

    }
}
