﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using KlasePodataka;

namespace KlaseMapiranja
{
    public class clsMaper
    {
        // atributi
        private string pStringKonekcije;

        // property

        // konstruktor
        public clsMaper(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }


        public string DajSifruZvanjaZaWebServis(string IdZvanjeIzBazePodataka)
        {
            string IDZvanjaWS = "";
            clsZvanjeDB objZvanjeDB = new clsZvanjeDB(pStringKonekcije);
            string nazivZvanjaIzBazePodataka = objZvanjeDB.DajNazivPremaIDZvanja(IdZvanjeIzBazePodataka);

            // sifra zvanja za web servis je prvo slovo naziva zvanja, znaci za docent je "d"
            IDZvanjaWS = nazivZvanjaIzBazePodataka[0].ToString();

            return IDZvanjaWS;

        }

    }
}
