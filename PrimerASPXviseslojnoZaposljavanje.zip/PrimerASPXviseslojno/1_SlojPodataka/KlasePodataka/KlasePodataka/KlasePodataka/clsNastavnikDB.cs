﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using System.Data.SqlClient;

namespace KlasePodataka
{
    public class clsNastavnikDB
    {
        // atributi
        private string pStringKonekcije;

        // property
        // 1. nacin
        public string StringKonekcije
        {
            get
            {
                return pStringKonekcije;
            }
        }
        // konstruktor
        // 2. nacin prijema vrednosti stringa konekcije spolja i dodele atributu
        public clsNastavnikDB(string NoviStringKonekcije)
        // OVO JE DOBRO JER OBAVEZUJE DA SE PRILIKOM INSTANCIRANJA OVE KLASE
        // MORA OBEZBEDITI STRING KONEKCIJE
        {
            pStringKonekcije = NoviStringKonekcije; 
        }

        // privatne metode

        // javne metode
        public DataSet DajSveNastavnike()
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet dsPodaci = new DataSet();

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajSveNastavnikeSaJoin", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();
            
            return dsPodaci;
        }

        public DataSet DajNastavnikaPoPrezimenu(string Prezime)
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet dsPodaci = new DataSet();

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajNastavnikaPoPrezimenu", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@NastavnikPrezime", SqlDbType.NVarChar).Value = Prezime;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();

            return dsPodaci;
        }


        public DataSet DajNastavnikaPoJMBG(int JMBG)
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet dsPodaci = new DataSet();

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajNastavnikaPoJMBG", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@NastavnikJMBG", SqlDbType.Int).Value = JMBG;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();

            return dsPodaci;
        }

        public int DajUkupnoNastavnikaZaZvanje(string IDZvanja)
        {
            int ukupnoNastavnika=0;
            DataSet dsPodaci = new DataSet();
            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajBrojNastavnikaZaZvanje", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@IDZvanja", SqlDbType.Char).Value = IDZvanja;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();
            ukupnoNastavnika = int.Parse(dsPodaci.Tables[0].Rows[0].ItemArray[0].ToString());  
            return ukupnoNastavnika;
        } 


        private clsNastavnikLista DajListuSvihNastavnika()
        {
            // PRIPREMA PROMENLJIVIH
            clsNastavnikLista objNastavnikLista = new clsNastavnikLista();
            DataSet dsPodaciNastavnika = new DataSet();
            clsNastavnik objNastavnik;
            clsZvanje objZvanje;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajSveNastavnikeSaJoinSifromZvanja", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaciNastavnika);
            Veza.Close();
            Veza.Dispose();

            // FORMIRANJE OBJEKATA I UBACIVANJE U LISTU
            for (int brojac = 0; brojac < dsPodaciNastavnika.Tables[0].Rows.Count; brojac++)
            {
                objZvanje = new clsZvanje();
                objZvanje.Sifra = dsPodaciNastavnika.Tables[0].Rows[brojac].ItemArray[4].ToString();
                objZvanje.Naziv = dsPodaciNastavnika.Tables[0].Rows[brojac].ItemArray[3].ToString();

                objNastavnik = new clsNastavnik();
                objNastavnik.JMBG = int.Parse (dsPodaciNastavnika.Tables[0].Rows[brojac].ItemArray [0].ToString ()); 
                objNastavnik.Prezime = dsPodaciNastavnika.Tables[0].Rows[brojac].ItemArray [0].ToString (); 
                objNastavnik.Ime = dsPodaciNastavnika.Tables[0].Rows[brojac].ItemArray [0].ToString ();
                objNastavnik.Zvanje =  objZvanje;
                objNastavnikLista.DodajElementListe (objNastavnik);
            }

            return objNastavnikLista;
        }
        

        public bool SnimiNovogNastavnika(clsNastavnik objNoviNastavnik)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova =0;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();

            SqlCommand Komanda = new SqlCommand("DodajNovogNastavnika", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@JMBG", SqlDbType.Int).Value = objNoviNastavnik.JMBG ;
            Komanda.Parameters.Add("@Prezime", SqlDbType.NVarChar ).Value = objNoviNastavnik.Prezime;
            Komanda.Parameters.Add("@Ime", SqlDbType.NVarChar).Value = objNoviNastavnik.Ime;
            Komanda.Parameters.Add("@IDZvanja", SqlDbType.Char).Value = objNoviNastavnik.Zvanje.Sifra;
            
           
            brojSlogova = Komanda.ExecuteNonQuery();
            Veza.Close();
            Veza.Dispose();
     
            // 2. varijanta
            return (brojSlogova > 0);

        }

        public bool ObrisiNastavnika(string JMBGNastavnikaZaBrisanje)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;
            // 1. varijanta - skolska 
            //bool uspehSnimanja= false;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();

            SqlCommand Komanda = new SqlCommand("ObrisiNastavnika", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@JMBG", SqlDbType.Int).Value = JMBGNastavnikaZaBrisanje;
            brojSlogova = Komanda.ExecuteNonQuery();
            Veza.Close();
            Veza.Dispose();

            return (brojSlogova > 0);

        }

        public bool IzmeniNastavnika(clsNastavnik objStariNastavnik, clsNastavnik objNoviNastavnik)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;
            // 1. varijanta - skolska 
            //bool uspehSnimanja= false;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();

            SqlCommand Komanda = new SqlCommand("IzmeniZvanje", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@StariJMBG", SqlDbType.Int).Value = objStariNastavnik.JMBG ;
            Komanda.Parameters.Add("@JMBG", SqlDbType.Int).Value = objNoviNastavnik.JMBG;
            Komanda.Parameters.Add("@Prezime", SqlDbType.NVarChar).Value = objNoviNastavnik.Prezime;
            Komanda.Parameters.Add("@Ime", SqlDbType.NVarChar).Value = objNoviNastavnik.Ime;
            Komanda.Parameters.Add("@IDZvanja", SqlDbType.Char).Value = objNoviNastavnik.Zvanje.Sifra;
            brojSlogova = Komanda.ExecuteNonQuery();
            Veza.Close();
            Veza.Dispose();

            return (brojSlogova > 0);

        }

        


    }
}
