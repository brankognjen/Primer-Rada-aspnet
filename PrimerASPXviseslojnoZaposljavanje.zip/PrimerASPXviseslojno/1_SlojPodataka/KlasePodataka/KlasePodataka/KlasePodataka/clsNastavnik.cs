﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class clsNastavnik
    {
        // atributi
        private int pJMBG;
        private string pPrezime;
        private string pIme;
        private clsZvanje objZvanje;

        // property
        public int JMBG
        {
            get { return pJMBG; }
            set { pJMBG = value; }
        }

        

        public string Prezime
        {
            get { return pPrezime; }
            set { pPrezime = value; }
        }

        

        public string Ime
        {
            get { return pIme; }
            set { pIme = value; }
        }
        

        public clsZvanje Zvanje
        {
            get { return objZvanje; }
            set { objZvanje = value; }
        }
    }
}
