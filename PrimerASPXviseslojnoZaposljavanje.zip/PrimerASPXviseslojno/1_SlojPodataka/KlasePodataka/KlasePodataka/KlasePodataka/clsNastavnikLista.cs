﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class clsNastavnikLista
    {

        // atributi
        private List<clsNastavnik> pListaNastavnika; 

        // property
        public List<clsNastavnik> ListaNastavnika
        {
            get
            {
                return pListaNastavnika;
            }
            set
            {
                if (this.pListaNastavnika != value)
                    this.pListaNastavnika = value;
            }
        }

        // konstruktor
        public clsNastavnikLista()
        {
            pListaNastavnika = new List<clsNastavnik>(); 

        }

        // privatne metode

        // javne metode
        public void DodajElementListe(clsNastavnik objNoviNastavnik)
        {
            pListaNastavnika.Add(objNoviNastavnik);
        }

        public void ObrisiElementListe(clsNastavnik objNastavnikZaBrisanje)
        {
            pListaNastavnika.Remove(objNastavnikZaBrisanje);  
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            pListaNastavnika.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(clsNastavnik objStariNastavnik, clsNastavnik objNoviNastavnik)
        {
            int indexStarogNastavnika = 0;
            indexStarogNastavnika = pListaNastavnika.IndexOf(objNoviNastavnik);
            pListaNastavnika.RemoveAt(indexStarogNastavnika);
            pListaNastavnika.Insert(indexStarogNastavnika, objNoviNastavnik);   
        }

           
    }
}
