﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class clsZvanjeLista
    {
        // atributi
        private List<clsZvanje> pListaZvanja; 

        // property
        public List<clsZvanje> ListaZvanja
        {
            get
            {
                return pListaZvanja;
            }
            set
            {
                if (this.pListaZvanja != value)
                    this.pListaZvanja = value;
            }
        }

        // konstruktor
        public clsZvanjeLista()
        {
            pListaZvanja = new List<clsZvanje>(); 

        }

        // privatne metode

        // javne metode
        public void DodajElementListe(clsZvanje objNovoZvanje)
        {
            pListaZvanja.Add(objNovoZvanje);
        }

        public void ObrisiElementListe(clsZvanje objZvanjeZaBrisanje)
        {
            pListaZvanja.Remove(objZvanjeZaBrisanje);  
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            pListaZvanja.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(clsZvanje objStaroZvanje, clsZvanje objNovoZvanje)
        {
            int indexStarogZvanja = 0;
            indexStarogZvanja = pListaZvanja.IndexOf(objStaroZvanje);  
            pListaZvanja.RemoveAt(indexStarogZvanja); 
            pListaZvanja.Insert(indexStarogZvanja, objNovoZvanje);   
        }

           

     




    }
}
